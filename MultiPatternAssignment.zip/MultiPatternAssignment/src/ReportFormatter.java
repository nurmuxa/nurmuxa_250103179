public interface ReportFormatter {
    public String format(String title , String[] headers , String[][] rows);
}
